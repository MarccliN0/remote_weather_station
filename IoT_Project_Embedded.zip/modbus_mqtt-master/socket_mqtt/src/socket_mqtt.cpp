/*
 ===============================================================================
 Name        : main.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
 ===============================================================================
 */

#if defined (__USE_LPCOPEN)
#if defined(NO_BOARD_LIB)
#include "chip.h"
#else
#include "board.h"
#endif
#endif

#include <cr_section_macros.h>

// TODO: insert other include files here
#include <cstdio>
#include <cstring>
#include "systick.h"
#include "LpcUart.h"
#include "esp8266_socket.h"
#include "retarget_uart.h"
#include "MQTTClient.h"
#include "DigitalIoPin.h"
#include "LiquidCrystal.h"
#include "I2C.h"
//#include "PhotoSens.h"

#define SSID	    "KME662"
#define PASSWORD  	"SmartIot"
#define BROKER_IP   "192.168.1.254"
#define BROKER_PORT  1883

// TODO: insert other definitions and declarations here
static volatile int counter;
static volatile uint32_t systicks;

DigitalIoPin *errorpin;

#define TICKRATE_HZ (100)	/* 100 ticks per second */

#if defined(BOARD_KEIL_MCB1500)
/* ADC is connected to the pot */
#define BOARD_ADC_CH 0
#define ANALOG_INPUT_PORT   1
#define ANALOG_INPUT_BIT    1
#define ANALOG_FIXED_PIN    SWM_FIXED_ADC1_0

#elif defined(BOARD_NXP_LPCXPRESSO_1549)
/* ADC is connected to the pot on LPCXPresso base boards */

#else
#warning "Using ADC channel 8 for this example, please select for your board"
#define BOARD_ADC_CH 8
#endif

static bool error = false;

#ifdef __cplusplus
extern "C" {
#endif
/**
 * @brief	Handle interrupt from SysTick timer
 * @return	Nothing
 */
void SysTick_Handler(void) {
	systicks++;
	if (counter > 0)
		counter--;

	static uint32_t count;

		/* Every 1/2 second */
		count++;
		if (count >= (TICKRATE_HZ / 2)) {
			count = 0;

			/* Manual start for ADC1 conversion sequence A */

		}
}

uint32_t get_ticks(void) {
	return systicks;
}

#ifdef __cplusplus
}
#endif

void Sleep(int ms) {
	counter = ms;
	while (counter > 0) {
		__WFI();
	}
}

/* this function is required by the modbus library */
uint32_t millis() {
	return systicks;
}

void messageArrived(MessageData *data) {
	printf("Message arrived on topic %.*s: %.*s\n",
			data->topicName->lenstring.len, data->topicName->lenstring.data,
			data->message->payloadlen, (char*) data->message->payload);

	errorpin->write(false);
	Sleep(20);
	errorpin->write(true);
}

void ADC_StartCalibration(LPC_ADC_T *pADC)
{
    // clock divider is the lowest 8 bits of the control register
    /* Setup ADC for about 500KHz (per UM) */
    uint32_t ctl = (Chip_Clock_GetSystemClockRate() / 500000) - 1;

    /* Set calibration mode */
    ctl |= ADC_CR_CALMODEBIT;

    pADC->CTRL = ctl;

    /* Calibration is only complete when ADC_CR_CALMODEBIT bit has cleared */
    while(pADC->CTRL & ADC_CR_CALMODEBIT) { };
}



int main(void) {

#if defined (__USE_LPCOPEN)
	SystemCoreClockUpdate();
#if !defined(NO_BOARD_LIB)
	Board_Init();
	Board_LED_Set(0, false);
#endif
#endif

	retarget_init();

	Chip_SWM_MovablePortPinAssign(SWM_SWO_O, 1, 2); // Needed for SWO printf

	/* Enable and setup SysTick Timer at a periodic rate */

	printf("\nBoot\n");

	setupI2CGPIO();
	setupI2C();

	Chip_ADC_Init(LPC_ADC0, 0);

	/* Setup for ADC clock rate */
	Chip_ADC_SetClockRate(LPC_ADC0, 500000);

	/* For ADC0, sequencer A will be used without threshold events.
	 It will be triggered manually, convert CH8 and CH10 in the sequence  */
	Chip_ADC_SetupSequencer(LPC_ADC0, ADC_SEQA_IDX,
			(ADC_SEQ_CTRL_CHANSEL(8) | ADC_SEQ_CTRL_CHANSEL(10)
					| ADC_SEQ_CTRL_MODE_EOS));

	// fix this and check if this is needed
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 0, (IOCON_MODE_INACT | IOCON_ADMODE_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 1, 0, (IOCON_MODE_INACT | IOCON_ADMODE_EN));
	/* For ADC0, select analog input pin for channel 0 on ADC0 */
	Chip_ADC_SetADC0Input(LPC_ADC0, 0);

	/* Use higher voltage trim for both ADC */
	Chip_ADC_SetTrim(LPC_ADC0, ADC_TRIM_VRANGE_HIGHV);

	/* Assign ADC0_8 to PIO1_0 via SWM (fixed pin) and ADC0_10 to PIO0_0 */
	Chip_SWM_EnableFixedPin (SWM_FIXED_ADC0_8);
	Chip_SWM_EnableFixedPin (SWM_FIXED_ADC0_10);

	/* Need to do a calibration after initialization and trim */
	//while (!(Chip_ADC_IsCalibrationDone(LPC_ADC0))); // The NXP library function violates their own access rules given in data sheet so we can't use it
	ADC_StartCalibration(LPC_ADC0);

	/* Set maximum clock rate for ADC */
	/* Our CPU clock rate is 72 MHz and ADC clock needs to be 50 MHz or less
	 * so the divider must be at least two. The real divider used is the value below + 1
	 */
	Chip_ADC_SetDivider(LPC_ADC0, 1);

	/* Chip_ADC_SetClockRate set the divider but due to rounding error it sets the divider too low
	 * which results in a clock rate that is out of allowed range
	 */
	//Chip_ADC_SetClockRate(LPC_ADC0, 500000); // does not work with 72 MHz clock when we want maximum frequency
	/* Clear all pending interrupts and status flags */
	Chip_ADC_ClearFlags(LPC_ADC0, Chip_ADC_GetFlags(LPC_ADC0));

	/* Enable sequence A completion interrupts for ADC0 */
	Chip_ADC_EnableInt(LPC_ADC0, ADC_INTEN_SEQA_ENABLE);
	/* We don't enable the corresponding interrupt in NVIC so the flag is set but no interrupt is triggered */

	/* Enable sequencer */
	Chip_ADC_EnableSequencer(LPC_ADC0, ADC_SEQA_IDX);

	/* Configure systick timer */
	SysTick_Config(Chip_Clock_GetSysTickClockRate() / TICKRATE_HZ);

	uint32_t a0;
	uint32_t d0;
	uint32_t a10;
	uint32_t d10;
	char str[80];

	DigitalIoPin errorpin(0, 27, DigitalIoPin::output);

	MQTTClient client;
	Network network;

	unsigned char sendbuf[256], readbuf[2556];
	int rc = 0, count = 0;
	MQTTPacket_connectData connectData = MQTTPacket_connectData_initializer;

	NetworkInit(&network, SSID, PASSWORD);
	MQTTClientInit(&client, &network, 30000, sendbuf, sizeof(sendbuf), readbuf,
			sizeof(readbuf));

	char *address = (char*) BROKER_IP;
	if ((rc = NetworkConnect(&network, address, BROKER_PORT)) != 0){
		printf("Return code from network connect is %d\n", rc);
		error = true;}

	connectData.MQTTVersion = 3;
	connectData.clientID.cstring = (char*) "esp_test";

	if ((rc = MQTTConnect(&client, &connectData)) != 0){
		printf("Return code from MQTT connect is %d\n", rc);
		error = true;}
	else
		printf("MQTT Connected\n");

	if ((rc = MQTTSubscribe(&client, "ConEnv/getdata", QOS2, messageArrived))
			!= 0){
		printf("Return code from MQTT subscribe is %d\n", rc);
		error = true;}

	// Enter an infinite loop, just incrementing a counter

	while (1) {
		measurementRequest();
		Sleep(5);
		dataFetch();
		MQTTMessage message;
		char buffer[60];
		if(error)
			errorpin.write(false);
		else
			errorpin.write(true);

		Chip_ADC_StartSequencer(LPC_ADC0, ADC_SEQA_IDX);

		// poll sequence complete flag
		while (!(Chip_ADC_GetFlags(LPC_ADC0) & ADC_FLAGS_SEQA_INT_MASK))
			;
		// clear the flags
		Chip_ADC_ClearFlags(LPC_ADC0, Chip_ADC_GetFlags(LPC_ADC0));

		// get data from ADC channels
		a0 = Chip_ADC_GetDataReg(LPC_ADC0, 8); // raw value
		d0 = ADC_DR_RESULT(a0); // ADC result with status bits masked to zero and shifted to start from zero
		a10 = Chip_ADC_GetDataReg(LPC_ADC0, 10);
		d10 = ADC_DR_RESULT(a10);
		int diff = (int) d0 - (int) d10;
		int lightlevel = d10 / 3.3;

		char temperBuffer[10];
		sprintf(temperBuffer, "%d", getTemperatureData());
		int temp = atoi(temperBuffer);

		char humBuffer[10];
		sprintf(humBuffer, "%d", getHumidityData());
		int hum = atoi(humBuffer);

		sprintf(buffer, "{\"Humidity\": %d,\"Temperature\": %d, \"lightlevel\": %d}", hum, temp, lightlevel);

		message.qos = QOS1;
		message.retained = 0;
		message.payload = buffer;
		message.payloadlen = strlen(buffer);

		if ((rc = MQTTPublish(&client, "ConEnv/getdata", &message)) != 0)
			printf("Return code from MQTT publish is %d\n", rc);

		if (rc != 0) {
			NetworkDisconnect(&network);
			// we should re-establish connection!!
			break;
		}

		// run MQTT for 100 ms
		if ((rc = MQTTYield(&client, 100)) != 0)
			printf("Return code from yield is %d\n", rc);

		Sleep(200);
	}

	printf("MQTT connection closed!\n");
	return 0;
}


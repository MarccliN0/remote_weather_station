/*
 * retarget_uart.h
 *
 *  Created on: 28.9.2021
 *      Author: keijo
 */

#ifndef RETARGET_UART_H_
#define RETARGET_UART_H_

void retarget_init();


#endif /* RETARGET_UART_H_ */

/*
 * PhotoSens.h
 *
 *  Created on: 2021. dec. 16.
 *      Author: MarccliN0
 */

#ifndef PHOTOSENS_H_
#define PHOTOSENS_H_

#include "board.h"

#include <stdio.h>

#define BOARD_ADC_CH 8

void ADC_StartCalibration(LPC_ADC_T *pADC);

void PhotoSensInit();

const char* runPhotoSens();



#endif /* PHOTOSENS_H_ */

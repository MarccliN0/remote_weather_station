/*
 * PhotoSens.c
 *
 *  Created on: 2021. dec. 16.
 *      Author: MarccliN0
 */
#include "PhotoSens.h"


void ADC_StartCalibration(LPC_ADC_T *pADC)
{
    // clock divider is the lowest 8 bits of the control register
    /* Setup ADC for about 500KHz (per UM) */
    uint32_t ctl = (Chip_Clock_GetSystemClockRate() / 500000) - 1;

    /* Set calibration mode */
    ctl |= ADC_CR_CALMODEBIT;

    pADC->CTRL = ctl;

    /* Calibration is only complete when ADC_CR_CALMODEBIT bit has cleared */
    while(pADC->CTRL & ADC_CR_CALMODEBIT) { };
}

void PhotoSensInit(){
	Chip_ADC_Init(LPC_ADC0, 0);

			/* Setup for ADC clock rate */
			Chip_ADC_SetClockRate(LPC_ADC0, 500000);

			/* For ADC0, sequencer A will be used without threshold events.
			   It will be triggered manually, convert CH8 and CH10 in the sequence  */
			Chip_ADC_SetupSequencer(LPC_ADC0, ADC_SEQA_IDX, (ADC_SEQ_CTRL_CHANSEL(8) | ADC_SEQ_CTRL_CHANSEL(10) | ADC_SEQ_CTRL_MODE_EOS));

			// fix this and check if this is needed
			Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 0, (IOCON_MODE_INACT | IOCON_ADMODE_EN));
			Chip_IOCON_PinMuxSet(LPC_IOCON, 1, 0, (IOCON_MODE_INACT | IOCON_ADMODE_EN));
			/* For ADC0, select analog input pin for channel 0 on ADC0 */
			Chip_ADC_SetADC0Input(LPC_ADC0, 0);

			/* Use higher voltage trim for both ADC */
			Chip_ADC_SetTrim(LPC_ADC0, ADC_TRIM_VRANGE_HIGHV);

			/* Assign ADC0_8 to PIO1_0 via SWM (fixed pin) and ADC0_10 to PIO0_0 */
			Chip_SWM_EnableFixedPin(SWM_FIXED_ADC0_8);
			Chip_SWM_EnableFixedPin(SWM_FIXED_ADC0_10);

			/* Need to do a calibration after initialization and trim */
			//while (!(Chip_ADC_IsCalibrationDone(LPC_ADC0))); // The NXP library function violates their own access rules given in data sheet so we can't use it
			ADC_StartCalibration(LPC_ADC0);

			/* Set maximum clock rate for ADC */
			/* Our CPU clock rate is 72 MHz and ADC clock needs to be 50 MHz or less
			 * so the divider must be at least two. The real divider used is the value below + 1
			 */
			Chip_ADC_SetDivider(LPC_ADC0, 1);

			/* Chip_ADC_SetClockRate set the divider but due to rounding error it sets the divider too low
			 * which results in a clock rate that is out of allowed range
			 */
			//Chip_ADC_SetClockRate(LPC_ADC0, 500000); // does not work with 72 MHz clock when we want maximum frequency

			/* Clear all pending interrupts and status flags */
			Chip_ADC_ClearFlags(LPC_ADC0, Chip_ADC_GetFlags(LPC_ADC0));

			/* Enable sequence A completion interrupts for ADC0 */
			Chip_ADC_EnableInt(LPC_ADC0, ADC_INTEN_SEQA_ENABLE);
			/* We don't enable the corresponding interrupt in NVIC so the flag is set but no interrupt is triggered */

			/* Enable sequencer */
			Chip_ADC_EnableSequencer(LPC_ADC0, ADC_SEQA_IDX);
}

const char* runPhotoSens(){
	uint32_t a0;
	uint32_t d0;
	uint32_t a10;
	uint32_t d10;

	char str[80];

	while(1){

	Chip_ADC_StartSequencer(LPC_ADC0, ADC_SEQA_IDX);

				// poll sequence complete flag
				while(!(Chip_ADC_GetFlags(LPC_ADC0) & ADC_FLAGS_SEQA_INT_MASK));
				// clear the flags
				Chip_ADC_ClearFlags(LPC_ADC0, Chip_ADC_GetFlags(LPC_ADC0));

				// get data from ADC channels
				a0 = Chip_ADC_GetDataReg(LPC_ADC0, 8); // raw value
				d0 = ADC_DR_RESULT(a0); // ADC result with status bits masked to zero and shifted to start from zero
				a10 = Chip_ADC_GetDataReg(LPC_ADC0, 10);
				d10 = ADC_DR_RESULT(a10);
				int diff = (int)d0 - (int)d10;
				sprintf(str, "%6d a0 = %08lX, d0 = %lu a10 = %08lX, d10 = %lu\n", diff, a0, d0, a10, d10);
				return str;
	}
}




